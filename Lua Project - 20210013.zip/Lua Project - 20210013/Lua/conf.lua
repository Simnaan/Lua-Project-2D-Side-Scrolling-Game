
function love.conf(t)
	t.title = "Platformer"	--This is the title of the window in which the game runs
	t.version = "11.4"		--this is the verson of love that the game is being made on
	t.console = true		--attach a console
	t.window.width = 1280	--this is the window width
	t.window.height = 720	--this is the windows hight
	t.window.vsync = 0 
end